gcc famtree.c -o famtree -lm 
./famtree <fam1.txt